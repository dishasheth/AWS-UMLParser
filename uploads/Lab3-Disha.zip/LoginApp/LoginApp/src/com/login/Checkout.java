package com.login;

import javax.jws.WebService;

import org.json.JSONObject;

@WebService
public class Checkout {

	
		public String getData(String username){
			
			Mysql mysqlObj = new Mysql();
			JSONObject result = new JSONObject();
			String resultToReturn="";
			
			try{
				System.out.println(username);
				result=mysqlObj.getData("Select * from user where userid='" + username+"'");
				System.out.println("printing result");
				System.out.println(result);
				resultToReturn=result.toString();
			}
			catch(Exception e){
				resultToReturn=result.toString();
				result.append("statusCode", 200);
			}
			return resultToReturn;
		} 
		
		
public String getDataFromCart(String username){
			
			Mysql mysqlObj = new Mysql();
			JSONObject result = new JSONObject();
			String resultToReturn="";
			
			try{
				result=mysqlObj.getData("Select * from shoppingcart where user_id='"+ username+"'");
				resultToReturn=result.toString();
			}
			catch(Exception e){
				resultToReturn=result.toString();
				result.append("statusCode", 200);
			}
			return resultToReturn;
		} 

public String getProduct(String productid){
	
	Mysql mysqlObj = new Mysql();
	JSONObject result = new JSONObject();
	String resultToReturn="";
	
	try{
		result=mysqlObj.getData("Select * from product where prod_id=" + productid);
		resultToReturn=result.toString();
	}
	catch(Exception e){
		resultToReturn=result.toString();
		result.append("statusCode", 200);
	}
	return resultToReturn;
}

public String getPay(String username){
	
	Mysql mysqlObj = new Mysql();
	JSONObject result = new JSONObject();
	String resultToReturn="";
	
	try{
		result=mysqlObj.getData("Select * from shoppingcart where user_id='"+ username+"'");
		resultToReturn=result.toString();
	}
	catch(Exception e){
		resultToReturn=result.toString();
		result.append("statusCode", 200);
	}
	return resultToReturn;
} 

public boolean updateProduct(String productid, int newquantity){
	
	Mysql mysqlObj = new Mysql();
	JSONObject result = new JSONObject();
	boolean resultToReturn=false;
	
	try{
		resultToReturn=mysqlObj.insertData("update product set prod_quantity=" + newquantity + " where prod_id=" + productid);
		
	}
	catch(Exception e){
		return false;
	}
	return resultToReturn;
} 

public boolean insertIntoBuyerInfo(String productid, int quantity, String username,int size){
	
	Mysql mysqlObj = new Mysql();
	JSONObject result = new JSONObject();
	boolean resultToReturn=false;
	
	try{
		resultToReturn=mysqlObj.insertData("insert into buyerinfo values ('" + username + "'," + productid + "," + quantity + ",'" + size+ "')");
		//resultToReturn=result.toString();
	}
	catch(Exception e){
		//resultToReturn=result.toString();
		//result.append("statusCode", 200);
		return false;
	}
	return resultToReturn;
} 

public boolean deleteCart(String username){
	
	Mysql mysqlObj = new Mysql();
	JSONObject result = new JSONObject();
	boolean resultToReturn=false;
	
	try{
		resultToReturn=mysqlObj.insertData("Delete from shoppingcart where user_id="+username);
		//resultToReturn=result.toString();
	}
	catch(Exception e){
		//resultToReturn=result.toString();
		//result.append("statusCode", 200);
		return false;
	}
	return resultToReturn;
} 



}

