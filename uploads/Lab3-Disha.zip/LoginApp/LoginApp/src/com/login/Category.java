package com.login;

import javax.jws.WebService;

import org.json.JSONObject;

@WebService
public class Category {
	
	public String getMainCategory(){
		
		Mysql mysqlObj = new Mysql();
		JSONObject result = new JSONObject();
		String resultToReturn="";
		
		try{
			result=mysqlObj.getData("Select * from categories where parent=0");
			resultToReturn=result.toString();
		}
		catch(Exception e){
			resultToReturn=result.toString();
			result.append("statusCode", 200);
		}
		return resultToReturn;
	} 
	
	
	public String getSubCategory(int id){
		
		
		Mysql mysqlObj = new Mysql();
		JSONObject result=new JSONObject();
		String resultToReturn ="";
		
		try{
			
			result=mysqlObj.getData("Select * from categories where parent="+id);
			resultToReturn = result.toString();
		}
		catch(Exception e){
			resultToReturn=result.toString();
			result.append("statusCode", 200);
		}
		return resultToReturn;
	}

}
