package com.login;

import javax.jws.WebService;

import org.json.JSONObject;

@WebService
public class Product {

	public String getProductByName(String name) {

		JSONObject results = new JSONObject();
		String results2 = "";
		try {
			results = Mysql.getData("Select * from product where prod_name='" + name + "'");

			results2 = results.toString();
		} catch (Exception e) {
			results2 = results.toString();
			results.append("statusCode", "401");
		}
		return results2;
	}

	public String addToCart(String username, String prod_id, String quantity, String size) {
		Mysql mysql = new Mysql();
		JSONObject results = new JSONObject();
		String results2 = "";
		try {

			String query = "Insert into shoppingcart(user_id,prod_id,quantity,size) values(" + username + "," + prod_id
					+ "," + quantity + ",'" + size + "')";
			mysql.insertData(query);
			results = mysql.getData("Select * from shoppingcart where user_id=" + username);
			results2 = results.toString();
		} catch (Exception e) {
			results.append("statusCode", 200);
			results2 = results.toString();
		}
		return results.toString();
	}

	public String getProductById(String id) {

		JSONObject results = new JSONObject();
		String results2 = "";
		try {
			results = Mysql.getData("Select * from product where prod_id='" + id + "'");

			results2 = results.toString();
		} catch (Exception e) {
			results2 = results.toString();
			results.append("statusCode", "401");
		}
		return results2;
	}

	public String viewCart(String username) {

		JSONObject results = new JSONObject();
		String results2 = "";
		try {
			results = Mysql.getData("Select * from shoppingcart where user_id=" + username);

			results2 = results.toString();
		} catch (Exception e) {
			results2 = results.toString();
			results.append("statusCode", "401");
		}
		return results2;
	}

	public String getSubCats(String fparent) {

		JSONObject results = new JSONObject();
		String results2 = "";
		try {
			results = Mysql.getData("Select * from categories where name='" + fparent + "'");

			results2 = results.toString();
		} catch (Exception e) {
			results2 = results.toString();
			results.append("statusCode", "401");
		}
		return results2;
	}

	public String getSubCatsByParent(String fparent) {

		JSONObject results = new JSONObject();
		String results2 = "";
		try {
			results = Mysql.getData("Select * from categories where parent='" + fparent + "'");

			results2 = results.toString();
		} catch (Exception e) {
			results2 = results.toString();
			results.append("statusCode", "401");
		}
		return results2;
	}

	public String getProductByCategory(String fparent) {

		JSONObject results = new JSONObject();
		String results2 = "";
		try {
			results = Mysql.getData("Select * from product where prod_category='" + fparent + "'");

			results2 = results.toString();
		} catch (Exception e) {
			results2 = results.toString();
			results.append("statusCode", "401");
		}
		return results2;
	}

	public boolean removeFromCart(String prod_id, String user_id) {

		JSONObject results = new JSONObject();
		boolean result = false;
		try {
			result = Mysql.insertData("Delete from shoppingcart where prod_id=" + prod_id + " and user_id=" + user_id);

			// results2=results.toString();
		} catch (Exception e) {
			// results2=results.toString();
			return false;
		}
		return result;
	}
}
