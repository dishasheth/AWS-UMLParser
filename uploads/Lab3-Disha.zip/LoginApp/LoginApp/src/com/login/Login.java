package com.login;

import java.security.MessageDigest;

import javax.jws.WebService;

import org.json.JSONObject;

@WebService
public class Login {

	public String validate(String username, String password) {

		JSONObject results = new JSONObject();
		String results2 = "";
		try {
			MessageDigest md = MessageDigest.getInstance("MD5");
			byte[] bytesOfMessage = password.getBytes("UTF-8");
			byte[] hashedPassword = md.digest(bytesOfMessage);
			System.out.println(username + "----------" + hashedPassword + "-------------" + password);
			results = Mysql
					.getData("Select * from user where email='" + username + "' and password='" + hashedPassword + "'");
			results2 = results.toString();
		} catch (Exception e) {
			results2 = results.toString();
			results.put("statusCode", "401");
		}
		return results2;
	}

	public String register(String username, String password, String firstname, String lastname, String mobile,
			String handle) {

		JSONObject results = new JSONObject();
		String results2 = "";
		try {

			MessageDigest md = MessageDigest.getInstance("MD5");
			byte[] bytesOfMessage = password.getBytes("UTF-8");
			byte[] hashedPassword = md.digest(bytesOfMessage);
			String query = "insert into user(firstname,lastname,email,password,mobile,ebayhandle,personal,business) values ('"
					+ firstname + "','" + lastname + "','" + username + "','" + hashedPassword + "','" + mobile + "','"
					+ handle + "','N','N')";
			Mysql.insertData(query);
			results = Mysql
					.getData("Select * from user where email='" + username + "' and password='" + hashedPassword + "'");
			results2 = results.toString();
		} catch (Exception e) {
			results.put("statusCode", 200);
			results2 = results.toString();
		}
		return results.toString();
	}
}
