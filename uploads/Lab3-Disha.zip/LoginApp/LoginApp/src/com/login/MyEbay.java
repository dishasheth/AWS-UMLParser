package com.login;

import javax.jws.WebService;

import org.json.JSONObject;

@WebService
public class MyEbay {
	public String purchase(String username) {

		JSONObject results = new JSONObject();
		String results2 = "";
		try {

			results = Mysql.getData(
					"select b.prod_name,a.quantity,b.prod_cost,b.prod_condition from buyerinfo a,product b where a.prod_id=b.prod_id and a.user_id="
							+ username);
			results2 = results.toString();
		} catch (Exception e) {
			results2 = results.toString();
			results.put("statusCode", 401);
		}
		return results2;
	}

	public String sell(String username) {

		JSONObject results = new JSONObject();
		String results2 = "";
		try {

			results = Mysql.getData("select * from product where prod_seller=" + username);
			results2 = results.toString();
		} catch (Exception e) {
			results2 = results.toString();
			results.put("statusCode", 401);
		}
		return results2;
	}
}
