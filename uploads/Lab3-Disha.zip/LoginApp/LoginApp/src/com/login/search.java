package com.login;

import javax.jws.WebService;

import org.json.JSONObject;

@WebService

public class search {
	public String listing(String query) {

		JSONObject results = new JSONObject();
		String results2 = "";
		try {

			results = Mysql.getData(query);
			results2 = results.toString();
		} catch (Exception e) {
			results2 = results.toString();
			results.put("statusCode", 401);
		}
		return results2;
	}
}
