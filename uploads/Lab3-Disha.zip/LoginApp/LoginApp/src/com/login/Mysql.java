package com.login;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import org.json.JSONArray;
import org.json.JSONObject;

public class Mysql {
	static Statement stmt;
	static Connection conn;
	static JSONObject json = new JSONObject();
	static JSONObject json2 = new JSONObject();

	public static JSONObject getData(String sql) {
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			conn = DriverManager.getConnection("jdbc:mysql://localhost/ebay1", "root", "system");
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			JSONArray jsonarray = new JSONArray();

			while (rs.next()) {
				json = new JSONObject();
				ResultSetMetaData rsmd = rs.getMetaData();
				for (int i = 1; i <= rsmd.getColumnCount(); i++) {
					String columnName = rsmd.getColumnName(i);
					String value = rs.getString(columnName);
					json.put(columnName, value);
				}
				jsonarray.put(json);
			}
			rs.close();
			stmt.close();
			conn.close();
			json2.put("statusCode", 200);
			json2.put("data", jsonarray);
		} catch (SQLException se) {
			se.printStackTrace();
			json2.append("statusCode", 401);
		} catch (Exception e) {
			e.printStackTrace();
			json2.append("statusCode", 401);
		} finally {
			try {
				if (stmt != null)
					stmt.close();
			} catch (SQLException se2) {
				json2.append("statusCode", 401);
			} // nothing we can do
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException se) {
				se.printStackTrace();
				json2.append("statusCode", 401);
			} // end finally try
		} // end try
		return json2;
	}// end main

	// ------------------------------------------------------------------------------------------------------

	// ---------------------------------------------------------------------------------------------------------
	public static Boolean insertData(String sql) {
		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			conn = DriverManager.getConnection("jdbc:mysql://localhost/ebay1", "root", "system");
			stmt = conn.createStatement();
			stmt.executeUpdate(sql);
			stmt.close();
			conn.close();
			return true;
		} catch (SQLException se) {
			se.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (stmt != null)
					stmt.close();
			} catch (SQLException se2) {
			} // nothing we can do
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException se) {
				se.printStackTrace();
			} // end finally try
		} // end try
		System.out.println("Goodbye!");
		return false;
	}// end main

}// end FirstExample