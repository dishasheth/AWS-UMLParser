package com.login;

import javax.jws.WebService;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

@WebService
public class Calculate {
	public float validate(String username) throws ScriptException {
		ScriptEngineManager manager = new ScriptEngineManager();
		ScriptEngine engine = manager.getEngineByName("js");
		float result = Integer.parseInt((engine.eval(username)).toString());
		System.out.println(result);
		return result;
	}
}
