package com.login;


import java.security.MessageDigest;

import javax.jws.WebService;

import org.json.JSONObject;

@WebService
public class Sell {
	
	
	public String addCategory(){
		Mysql mysql=new Mysql();
		JSONObject results=new JSONObject();
		String results2="";
		try{
		
        results=mysql.getData("select * from categories where parent in (select id from categories where parent=0)");
		 results2=results.toString();
		}
		catch(Exception e)
		{
			results2=results.toString();
			results.put("statusCode", "401");
		}
	    return results2;
	}
	public String getCatIdbyName(String category){
		Mysql mysql=new Mysql();
		 JSONObject results=new JSONObject();
		 String results2="";
		 try{     
        results=mysql.getData("select id from categories where name='"+category+"'");
        results2=results.toString();
		}
		catch(Exception e)
		{
			results.put("statusCode", 200);
			 results2=results.toString();
		}
	    return results.toString();
	}
	public boolean addProduct(String title,String prod_cat,String seller,String quantity,String price,String brand,String condition, String size,String details,String listing,String starting)
	{
		
		boolean result=Mysql.insertData("insert into product(prod_name,prod_category,prod_seller,prod_quantity,prod_cost,brand,prod_condition,prod_size,details,prod_listing,prod_starting) values ('"+title+"','"+prod_cat+"','"+seller+"','"+quantity+"','"+price+"','"+brand+"','"+condition+"','"+size+"','"+details+"','"+listing+"','"+starting+"')");
		return result;
		
	}
}
