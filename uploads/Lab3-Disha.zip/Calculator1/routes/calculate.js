/**
 * http://usejsdoc.org/
 *//*

exports.makeCalculation=function(req,res){
	//var math = require('/mathjs');
	console.log("in");
	var x=req.param("exp");
	//console.log(req.data.status);
	console.log(x);
	//evaluate(x);
	//console.log(eval(x));
	try{
		var result=eval(x);
	}
	catch(e){
		json_responses = {"statusCode" : 401,"error":"Invalid expression"};
		res.send(json_responses);
	}
	
	var json_responses;
	if(result!==Infinity)
	{
		console.log(result);
	json_responses = {"statusCode" : 200, "result" : result};
	res.send(JSON.stringify(json_responses));
	}
else
	{
	json_responses = {"statusCode" : 401,"error":"Cannot divide by zero"};
	res.send(json_responses);
	}
	//var ans=math.eval(x);
	//console.log(ans);
		
};


*/




var soap = require('soap');
var baseURL = "http://localhost:8081/LoginApp/services";

exports.makeCalculation = function(req,res){
	var option = {
			ignoredNamespaces : true	
		};
	 var url = baseURL+"/Calculate?wsdl";
	  var args = {username: req.param("exp")};
	  soap.createClient(url,option, function(err, client) {
	      client.validate(args, function(err, result) {
	    	  if(result.validateReturn!=undefined){
	    	  console.log(result.validateReturn.$value);
	    		  json_responses = {"statusCode" : 200, "result" : result.validateReturn.$value};
	    		  res.send(json_responses);
	    	  }
	    	  else
	    		  {
	    		  json_responses = {"statusCode" : 401, "error" : "Improper expression"};
	    		  res.send(json_responses);
	    		  }
	      });
	  });
};
