/**
 * New node file
 */

exports.showCart = function(req, res){
  res.render('cart');
};