var mysql = require("./mysql1");
var logger = require("./Logger");

var soap = require('soap');
var baseURL = "http://localhost:8081/LoginApp/services";

exports.getItem = function(req, res) {
	var user = req.session.username;
	res.render('ProductDetails', {
		user : user
	})
}
exports.showcart = function(req, res) {
	var user = req.session.username;
	res.render('cart', {
		user : user
	})
}
exports.getItemDetails = function(req, res) {
	var json_responses;
	var product = req.param("prod");
	var option = {
		ignoredNamespaces : true
	};
	var url = baseURL + "/Product?wsdl";
	var args = {
		name : product
	};

	if (req.session.username) {
		logger.log("Browsing product with name " + product + " for user : "
				+ req.session.username);
	}
	soap.createClient(url, option, function(err, client) {
		client.getProductByName(args, function(err, result) {
			var datareceived = JSON.parse(result.getProductByNameReturn);
			console.log(datareceived);
			if (datareceived.statusCode == 401) {
				res.send({
					"statusCode" : "401"
				});
			} else {
				var rows = datareceived.data;
				var product = {};
				for ( var i in rows) {
					var row = rows[i];

					product = {
						name : row.prod_name,
						condition : row.prod_condition,
						size : row.prod_size,
						quantity : row.prod_quantity,
						cost : row.prod_cost,
						brand : row.brand,
						image : row.img,
						prod_id : row.prod_id

					}
					json_responses = {
						"statusCode" : 200,
						"pdetails" : product
					};
					res.send(json_responses);

				}

			}
		});
	});
}
exports.addToCart = function(req, res) {
	var json_responses;
	var prod_id = req.param("prod_id");
	var quantity = req.param("quantity");
	var size = req.param("size");
	var username = "";
	var productsincart = [];
	var products = [];
	if (req.session.username) {
		logger.log("Adding product with id : " + prod_id + " to cart for user"
				+ req.session.username);
	}
	if (req.session.userid) {
		username = req.session.userid;
		var option = {
			ignoredNamespaces : true
		};
		var url = baseURL + "/Product?wsdl";
		var args = {
			username : username,
			prod_id : prod_id,
			quantity : quantity,
			size : size
		};

		if (req.session.username) {
			logger.log("Browsing product with name " + prod_id + " for user : "
					+ req.session.username);
		}
		soap.createClient(url, option, function(err, client) {
			client.addToCart(args, function(err, result) {
				var datareceived = JSON.parse(result.addToCartReturn);
				console.log(datareceived);
				if (datareceived.statusCode == 401) {
					res.send({
						"statusCode" : "401"
					});
				} else {
					var name = "";
					var quantity = "";
					var cost = "";
					var size = "";
					var brand = ""
					var productid = "";
					var image = "";
					var rows = datareceived.data;
					for ( var i in rows) {
						productid = rows[i].prod_id;
						quantity = rows[i].quantity;
						size = rows[i].size;
						products.push(rows[i]);

					}
					var j = 0;
					var counter = 0;
					for (j in products) {
						var args = {
							id : products[j].prod_id
						};

						soap.createClient(url, option, function(err, client) {
							client.getProductById(args, function(err, result) {
								var datareceived = JSON
										.parse(result.getProductByIdReturn);
								console.log(datareceived);
								if (datareceived.statusCode == 401) {
									res.send({
										"statusCode" : "401"
									});
								} else {
									rows=datareceived.data;
									quantitynew = products[counter].quantity;
									sizenew = products[counter].size
									counter = counter + 1;
									for (i in rows) {
										name = rows[i].prod_name;
										cost = rows[i].prod_cost;
										brand = rows[i].brand;
										image = rows[i].img;
										productid = rows[i].prod_id;

										var product = {
											"name" : name,
											"size" : sizenew,
											"quantity" : quantitynew,
											"cost" : cost,
											"brand" : brand,
											"image" : image,
											"id" : productid

										}
										productsincart.push(product);
										console.log("cart-------------"+productsincart);
									}
									if (counter == products.length) {
										json_responses = {
											"statusCode" : 200,
											"pdetails" : productsincart
										};
										res.send(json_responses);
									}

								}
							});
						});

					}

				}

			});
		});
	} else {
		json_responses = {
			"statusCode" : 401
		};
		res.send(json_responses);

	}

};
exports.viewcart = function(req, res) {

	var json_responses;

	var username = "";
	var productsincart = [];
	var products = [];
	if (req.session.username) {
		logger.log("Browsing cart for user " + req.session.username);
	}
	if (req.session.userid) {
		username = req.session.userid;

		var option = {
				ignoredNamespaces : true
			};
			var url = baseURL + "/Product?wsdl";
			var args = {
				username : req.session.userid
				
			};

			
			
			soap.createClient(url, option, function(err, client) {
				client.viewCart(args, function(err, result) {
					var datareceived = JSON.parse(result.viewCartReturn);
					console.log(datareceived);
					if (datareceived.statusCode == 401) {
						res.send({
							"statusCode" : "401"
						});
					} else {
								var name = "";
								var quantity = "";
								var cost = "";
								var size = "";
								var brand = ""
								var image = "";
								rows=datareceived.data;
								for ( var i in rows) {
									var productid = rows[i].prod_id;
									quantity = rows[i].quantity;
									size = rows[i].size;
									products.push(rows[i]);

								}
								var j = 0;
								var counter = 0;
								for (j in products) {
									var args = {
											id : products[j].prod_id
										};

										soap.createClient(url, option, function(err, client) {
											client.getProductById(args, function(err, result) {
												var datareceived = JSON
														.parse(result.getProductByIdReturn);
												console.log(datareceived);
												if (datareceived.statusCode == 401) {
													res.send({
														"statusCode" : "401"
													});
												} else {

															quantitynew = products[counter].quantity;
															sizenew = products[counter].size
															counter = counter + 1;
															rows=datareceived.data;
															for (i in rows) {
																name = rows[i].prod_name;
																cost = rows[i].prod_cost;
																brand = rows[i].brand;
																image = rows[i].img;
																var productid = rows[i].prod_id;
																
																var product = {
																	"name" : name,
																	"size" : sizenew,
																	"quantity" : quantitynew,
																	"cost" : cost,
																	"brand" : brand,
																	"image" : image,
																	"id" : productid

																}
																console.log(product);
																productsincart
																		.push(product);

															}
															if (counter == products.length) {
																json_responses = {
																	"statusCode" : 200,
																	"pdetails" : productsincart
																};
																res
																		.send(json_responses);
															}

														}
													});});

								}

							}

						});});
	} else {
		json_responses = {
			"statusCode" : 401
		};
		res.send(json_responses);

	}
	
};

exports.getSubcats = function(req, res) {
	var json_responses;
	var fparent = req.param("cat");
	console.log("Entering /subcats" + fparent);

	var option = {
			ignoredNamespaces : true
		};
		var url = baseURL + "/Product?wsdl";
		var args = {
			fparent :fparent	
		};

		soap.createClient(url, option, function(err, client) {
			client.getSubCats(args, function(err, result) {
				var datareceived = JSON.parse(result.getSubCatsReturn);
				console.log(datareceived);
				if (datareceived.statusCode == 401) {
					res.send({
						"statusCode" : "401"
					});
				} else {
					rows=datareceived.data;
						var cat_id;
							console.log("Fetching category for categoryid"
									+ fparent);
							rows=datareceived.data;
							for ( var i in rows) {
								var row = rows[i];

								var name = row.name;
								fparent = row.id;
							}
						}

						var json_responses;
						var categories = {};
						console.log("Fetching sub categories..............")
						var cats = [];
						var args = {
								fparent :fparent	
							};


						soap.createClient(url, option, function(err, client) {
							client.getSubCatsByParent(args, function(err, result) {
								var datareceived = JSON.parse(result.getSubCatsByParentReturn);
								console.log(datareceived);
								if (datareceived.statusCode == 401) {
									res.send({
										"statusCode" : "401"
									});
								} else {
									rows=datareceived.data;
												var cat_id;
											
												console
														.log("results is"
																+ rows);
												for ( var i in rows) {
													var row = rows[i];

													var name = row.name;
													cat_id = row.id;
													cats.push(row)
													console.log(cat_id);

												}
												var subcats = [];
												for ( var i in cats) {
													var json_responses;
													var categories = {};
													console.log("Fetching sub categories..............")
											
													var args = {
															fparent :cats[i].id	
														};

													soap.createClient(url, option, function(err, client) {
														client.getSubCatsByParent(args, function(err, result) {
															var datareceived = JSON.parse(result.getSubCatsByParentReturn);
															console.log(datareceived);
															if (datareceived.statusCode == 401) {
																res.send({
																	"statusCode" : "401"
																});
															} else {
																  var allcategories = [];
																rows=datareceived.data;
																for ( var j in rows) {
																				allcategories
																						.push(rows[j].name);
																			}
																			subcats
																					.push(allcategories);
																			console
																					.log(allcategories);
																			// console.log(name)
																			if (cats.length == subcats.length) {
																				for ( var i in cats) {
																					var name = cats[i].name;
																					console
																							.log(name);
																					categories[cats[i].name] = subcats[i];

																				}
																				var products = [];
																				var args = {
																						fparent :fparent
																					};
																				soap.createClient(url, option, function(err, client) {
																					client.getProductByCategory(args, function(err, result) {
																						var datareceived = JSON.parse(result.getProductByCategoryReturn);
																						console.log(datareceived);
																						if (datareceived.statusCode == 401) {
																							res.send({
																								"statusCode" : "401"
																							});
																						} else {
																							rows=datareceived.data;
																							var cat_id;
																										console
																												.log("Fetching products for categoryid"
																														+ fparent);
																										for ( var i in rows) {
																											var row = rows[i];

																											var name = {
																												"name" : row.prod_name,
																												"img" : row.img
																											};

																											products
																													.push(name)

																										}
																										console
																												.log(categories);
																										console
																												.log(products);
																										json_responses = {
																											"statusCode" : 200,
																											"category" : categories,
																											"products" : products
																										};
																										res
																												.send(json_responses);
																										console
																												.log("Done Fetching sub categories..............");

																									}
																								});});
																			}
																		}
																	});});
												}
											}});});
										});
					});

};

exports.removefromcart = function(req, res) {
	if (req.session.userid) {
		var id = req.param("id");

		var option = {
				ignoredNamespaces : true
			};
			var url = baseURL + "/Product?wsdl";
			var args = {
				prod_id :id,
				user_id: req.session.userid
			};


		soap.createClient(url, option, function(err, client) {
			client.removeFromCart(args, function(err, result) {
				var datareceived = JSON.parse(result.removeFromCartReturn);
				console.log(datareceived);
				if (datareceived=== false) {
					res.send({
						"statusCode" : "401"
					});
				} else {

				res.redirect("/rendercart");

			}
			});		});

	}

}

exports.getproducts=function(req,res)
{
 
 var cat=req.param("pcat");
 var pname="%"+req.param("pname")+"%";
 console.log(cat);
 var option = {
   ignoredNamespaces : true 
  };
  var url = baseURL+"/search?wsdl";
  
 if(cat==="All%20Categories")
  {
   var query="select * from product where prod_name like '"+pname+"' or brand like '"+pname+"'";
    var args = {query: query};
  }
 else
  {
  var query="select * from product where prod_name like '"+pname+"' or brand like '"+pname+"' and prod_subcategory IN (select id from categories where name='"+cat+"') ";
   var args = {query: query};
  }
 
   soap.createClient(url, option, function(err, client) {
   client.listing(args, function(err, result) {
    var datareceived = JSON.parse(result.listingReturn);
    console.log(datareceived);
    if (datareceived.statusCode == 401) {
     res.send({
      "statusCode" : "401"
     });
    } else {
     if (datareceived.data.length == 0) {
      res.send({
       "statusCode" : "401"
      });
     } else {
      
     var rows = datareceived.data;
     for ( var i in rows) {
      console.log("valid Login"+(rows[i].prod_name)); 
     }
     json_responses = {"statusCode" : 200,"results":rows};
     console.log("before redirect");
     res.send(json_responses);
    }
   }});
  });
 
/* mysql.fetchData(function(err,results){
  if(err){
   console.log("Invalid Login");
  throw err;
  
  }
  else
  {
  if(results.length > 0){
  for(var i=0;i<results.length;i++) 
  console.log("valid Login"+results[i].prod_name);
  createlog.setlog(req.session.email+" Searched for product "+pname+" and Category "+cat);
  json_responses = {"statusCode" : 200,"results":results};
  console.log("before redirect");
  res.send(json_responses);
  }
  else {
  console.log("No products");
  json_responses = {"statusCode" : 401};
  res.send(json_responses);
  
  }
  }
  },query);*/
 
 
 };