/**
 * New node file
 */
var mysql=require('./mysql1');
var logger=require('./Logger');

var soap = require('soap');
var baseURL = "http://localhost:8081/LoginApp/services";

exports.sellProduct = function(req, res){

	if(req.session.username)
	res.render('sell',{user:req.session.username});
	else
	res.redirect('/login');
};


exports.addCategory=function(req,res){
	console.log("here");
	var json_responses;
	var cat=[];
	var option = {
			ignoredNamespaces : true
		};
		var url = baseURL + "/Sell?wsdl";
		var args = {
		
		};

	soap.createClient(url, option, function(err, client) {
		client.addCategory(args, function(err, result) {
			var datareceived = JSON.parse(result.addCategoryReturn);
			console.log(datareceived);
			if (datareceived.statusCode == 401) {
				res.send({
					"statusCode" : "401"
				});
			} else {
				
			var results=datareceived.data;
		for(var i=0;i<results.length;i++){
			cat.push(results[i].name);
		}
		console.log(cat);
		//console.log("Inserted"+results[0].firstname);
		/*req.session.username=results[0].firstname;*/
		json_responses = {"statusCode" : 200,"cat" : cat};
		console.log("before redirect");
		res.send(json_responses);	
		}
		});});	
}



exports.addProduct=function(req,res)
{
	
	if(req.session.username)
		{
		logger.log("Adding selling items for user :"+ req.session.username);
		}
	console.log("here");
	var json_responses;
	var title = req.param("title");
	var size = req.param("size");
	var condition=req.param("condition");
	var brand=req.param("brand");
	var details=req.param("details");
	var category=req.param("category").trim();
	var starting=req.param("starting");
	var price=req.param("price");
	var quantity=req.param("quantity");
	var size=req.param("size");
	var listing="fixed";
	var prod_cat="";
	var seller=req.session.userid;
	if(starting==undefined){ starting=0; }
	if(req.param("fixed")===true){ listing="auction";}
	/*var query = "insert into product(prod_title,prod_brand,details,prod_listing,prod_starting,prod_price,prod_quantity,prod_condition) values ('"+title+"','"+brand+"','"+details+"','"+listing+"','"+starting+"','"+price+"','"+quantity+"','"+condition+"')";*/
	
	
	var option = {
			ignoredNamespaces : true
		};
		var url = baseURL + "/Sell?wsdl";
		var args = {
				category:category
		};

	soap.createClient(url, option, function(err, client) {
		client.getCatIdbyName(args, function(err, result) {
			var datareceived = JSON.parse(result.getCatIdbyNameReturn);
			console.log(datareceived);
			if (datareceived.statusCode == 401) {
				res.send({
					"statusCode" : "401"
				});
			} else {
				
			var rows=datareceived.data;
			console.log("Results :"+rows);
			prod_cat=rows[0].id;
			
			console.log(prod_cat+" "+seller);
		
			var args = {
					title:title,
					prod_cat:prod_cat,
					seller:seller,
						quantity:quantity,
						price:price,
						brand:brand,
						condition:condition,
						size:size,
						details:details,
						listing:listing,
						starting:starting
			};
			soap.createClient(url, option, function(err, client) {
				client.addProduct(args, function(err, result) {
					var datareceived = JSON.parse(result.addProductReturn);
					console.log(datareceived);
					if (datareceived === false) {
						res.send({
							"statusCode" : "401"
						});
					} else {
				json_responses = {"statusCode" : 200};
				console.log("before redirect");
				res.send(json_responses);
				}
				});
			});
			}
		
		});
	});
	

};