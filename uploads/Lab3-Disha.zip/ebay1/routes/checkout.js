var mysql = require("./mysql1");

var soap = require('soap');
var baseURL = "http://localhost:8081/LoginApp/services";
var counter = 0;

exports.rendercheckout = function(req, res) {
	if (req.session.userid) {
		var user = req.session.username;
		res.render('Checkout', {
			user : user
		});

	} else {
		res.render('login', {
			title : "Please Login first"
		});
	}
};

exports.checkout = function(req, res) {
	var json_responses;
	var direct = "";

	direct = req.param("direct");
	var username = "";

	counter = 0;
	if (req.session.userid) {
		var username = req.session.userid;
		var quantity = "";
		var size = "";
		var products = [];
		var address = "";
		var productsincart = [];

		var json_responses;
		var option = {
				ignoredNamespaces : true
		};
		var url = baseURL + "/Checkout?wsdl";
		var argGetData = {
				username:username
		};

		soap.createClient(url,option,function(err, client) {
			client.getData(argGetData,function(err,result){
				
				console.log(argGetData);
				var datareceived = JSON.parse(result.getDataReturn);
				if (datareceived.statusCode == 401) {
					res.send({
						"statusCode" : "401"
					});
				} else {
					var rows = datareceived.data;
					console.log("finding address......");
					console.log(rows);
					address = rows[0].address;
					console.log(direct);
					if (direct == "true") {
						console.log("Entering direct true" + prod_id);
						var prod_id = req.param("prod_id");
						quantity = req.param("quantity");
						size = req.param("size");
						getProduct(size, quantity, prod_id, res, address, 1,
								productsincart,username);
					} else {

						client.getDataFromCart(argGetData, function(err, resultAgain) {
							var datareceivedAgain = JSON.parse(resultAgain.getDataFromCartReturn);
							if (datareceivedAgain.statusCode == 401) {
								res.send({
									"statusCode" : "401"
								});
							} else {
								console.log("Entering /addtocart" + username);
								var rows = datareceivedAgain.data;
								for ( var i in rows) {
									var productid = rows[i].prod_id;
									quantity = rows[i].quantity;
									size = rows[i].size;
									products.push(rows[i]);

								}
								var k = 0;

								for (k in products) {
									getProduct(products[k].size,
											products[k].quantity,
											products[k].prod_id, res, address,
											products.length, productsincart,username);
								}
							}
						});
					}
				}



			});
		});

	}else {
		json_responses = {
				"statusCode" : 401
		};
		res.send(json_responses);

	}

};
var getProduct = function(size, quantity, productid, res, address, length,
		productsincart,username) {
	var name = "";
	var cost = "";
	var brand = ""
		var image = "";

	var json_responses;
	var option = {
			ignoredNamespaces : true
	};
	var url = baseURL + "/Checkout?wsdl";
	var argGetData = {
			productid:productid
	};

	soap.createClient(url,option,function(err, client) {
		client.getProduct(argGetData,function(err,result){

			var datareceived = JSON.parse(result.getProductReturn);
			if (datareceived.statusCode == 401) {
				res.send({
					"statusCode" : "401"
				});
			} else {
				counter = counter + 1;
				console.log("Entering /addtocart" + quantity);
				var rows = datareceived.data;
				for (i in rows) {
					name = rows[i].prod_name;
					cost = rows[i].prod_cost;
					brand = rows[i].brand;
					image = rows[i].img;
					var product = {
							"name" : name,
							"size" : size,
							"quantity" : quantity,
							"cost" : cost,
							"brand" : brand,
							"image" : image

					}
					console.log("add to cart" + product);
					productsincart.push(product);

				}

				if (counter == length) {
					json_responses = {
							"statusCode" : 200,
							"pdetails" : productsincart,
							"address" : address
					};
					res.send(json_responses);
				}




			}
		});
	});
		return counter;
	};
	
	
	exports.pay = function(req, res) {
		var json_responses;
		var direct = "";

		direct = req.param("direct");
		var username = "";

		counter = 0;
		if (req.session.userid) {
			var username = req.session.userid;
			var quantity = "";
			var size = "";
			var products = [];
			var address = "";
			var productsincart = [];
			console.log("Entering direct" + direct);
			if (direct == "true") {

				var prod_id = req.param("prod_id");
				quantity = req.param("quantity");
				size = req.param("size");
				console.log("Entering direct true" + prod_id + " " + size + " "
						+ quantity);

				insertbuyerinfo(size, quantity, prod_id, res, 1, username)


			} else {

				var json_responses;
				var option = {
						ignoredNamespaces : true
				};
				var url = baseURL + "/Checkout?wsdl";
				var argGetData = {
						username:username
				};

				soap.createClient(url,option,function(err, client) {
					client.getPay(argGetData,function(err,result){

						var datareceived = JSON.parse(result.getPayReturn);
						if (datareceived.statusCode == 401) {
							res.send({
								"statusCode" : "401"
							});
						}  else {
							var rows = datareceived.data;
							for ( var i in rows) {
								var productid = rows[i].prod_id;
								quantity = rows[i].quantity;
								size = rows[i].size;
								products.push(rows[i]);

							}
							var k = 0;

							for (k in products) {

								insertbuyerinfo(products[k].size, products[k].quantity,
										products[k].prod_id, res, products.length,
										username);

							}
						}
					});
				});
			}

		}

		else {
			json_responses = {
					"statusCode" : 401
			};
			res.send(json_responses);

		}

	};

	var insertbuyerinfo = function(size, quantity, productid, res, length, username) {


		var json_responses;
		var option = {
				ignoredNamespaces : true
		};
		var url = baseURL + "/Checkout?wsdl";
		var argGetData = {
				productid:productid
		};

		soap.createClient(url,option,function(err, client) {
			client.getProduct(argGetData,function(err,result){

				var datareceived = JSON.parse(result.getProductReturn);
				var rows=datareceived.data;

				var prod = rows[0];
				console.log(prod.prod_quantity+"  "+quantity);
				if (prod.prod_quantity >= quantity) {
					var newquantity = prod.prod_quantity - quantity;
					console.log(newquantity);

					var argUpdateProduct = {
							productid:productid,
							newquantity:newquantity
					};

					client.updateProduct(argUpdateProduct, function(err, updateResult) {
						var datareceived = JSON.parse(updateResult.updateProductReturn);
						if (!datareceived.data) {
							res.send({
								"statusCode" : "401"
							});
						}  else {

							var arginsert={

									username:username,
									productid:productid,
									quantity:quantity,
									size:size
							};


							client.insertIntoBuyerInfo(arginsert, function(err, resultInsertBuyer) {
								var datareceived = JSON.parse(resultInsertBuyer.insertIntoBuyerInfoReturn);
								if (!datareceived.data) {
									res.send({
										"statusCode" : "401"
									});
								}  else {
									counter = counter + 1;
									if (counter == length) {

										argDelete={
												username:username
										};

										client.deleteCart(argDelete, function(err,resultDeleteCart){
											var datareceived = JSON.parse(resultDeleteCart.deleteCartReturn);
											if (!datareceived.data) {
												res.send({
													"statusCode" : "401"
												});
											} 
											else
											{
												json_responses = {
														"statusCode" : 200
												};
												res.send(json_responses);
											}});}

								}
							});
						}
					});

				} else {
					json_responses = {
							"statusCode" : 402
					};
					res.send(json_responses);
				}
			});
		});

		};
		var updatequantity = function(quantity, productid, res, length) {
			var json_responses;
			var option = {
					ignoredNamespaces : true
			};
			var url = baseURL + "/Checkout?wsdl";
			var argGetData = {
					productid:productid
			};

			soap.createClient(url,option,function(err, client) {
				client.getProduct(argGetData,function(err,result){

					var datareceived = JSON.parse(result.getProductReturn);
					var rows=datareceived.data;
					var prod = rows[0];
					console.log(prod.prod_quantity);
					if (prod.prod_quantity >= quantity) {
						var newquantity = prod.prod_quantity - quantity;
						console.log(newquantity);


						var argUpdateProduct = {
								productid:productid,
								newquantity:quantity
						};

						client.updateProduct(argUpdateProduct, function(err, updateResult) {
							var datareceived = JSON.parse(updateResult.updateProductReturn);
							if (!datareceived.data) {
								res.send({
									"statusCode" : "401"
								});
							}  else {
								counter = counter + 1;
								if (counter == length) {
									return true;
								}
							}
						});

					} else {
						return false;
					}
				});
			});

		};
