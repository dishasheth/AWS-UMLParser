



var mysql=require('./mysql1');
var ejs = require("ejs");
var bcrypt = require('bcryptjs');
var soap = require('soap');
var baseURL = "http://localhost:8081/LoginApp/services";
var createlog=require("./createLog");

exports.checkLogin = function(req,res){
	// These two variables come from the form on
	// the views/login.hbs page
	//console.log("in checklogin");
	var username = req.param("user");
	var password = req.param("pass");
	
	
	console.log(username+" "+password);
	ejs.renderFile('./views/login.ejs',function(err, result) {
		// render on success
		if (!err) {
		res.end(result);
		}
		// render or error
		else {
		res.end('An error occurred');
		console.log(err);
		}
		});
	};
	
	exports.loginDetails=function(req,res)
	{
		
		//var getUser="select * from test.users where username='"+req.param("inputUsername")+"' and password='" +req.param("inputPassword") +"'";
		//console.log("Query is11:"+getUser);
		
		var json_responses;
		var username = req.param("user");
		var password = req.param("pass");
/*		var json_responses;
		var option = {
			ignoredNamespaces : true
		};
		var url = baseURL + "/Login?wsdl";
		var args = {
			username : username,
			password : password
		};
		soap.createClient(url, option, function(err, client) {
			client.validate(args, function(err, result) {
				var datareceived = JSON.parse(result.validateReturn);
				console.log(datareceived);
				if (datareceived.statusCode == 401) {
					res.send({
						"statusCode" : "401"
					});
				} else {
					if (datareceived.data.length === 0) {
						res.send({
							"statusCode" : "401"
						});
					} else {
						
					var rows = datareceived.data;
					for ( var i in rows) {

						req.session.userid = rows[i].userid;
						user_id = rows[i].userid;
						username =rows[i].firstname;
						req.session.userid=results[0].userid;
						req.session.email=results[0].email;
						req.session.fname=results[0].firstname;
						req.session.lastname=results[0].lastname;
						req.session.mobile=results[0].mobile;
						req.session.ebayhandle=results[0].ebayhandle;
						
						createlog.setlog(req.session.email+" Logged into system");

						console.log("Session initialized for user : " + username);
						json_responses = {
							"statusCode" : 200
						};
						res.send(json_responses);
					}

				}
			}});
		});
		*/
		
	var hashpass=bcrypt.hashSync(password,bcrypt.genSaltSync(9));
		
		console.log(hashpass);
		
var hashpass1=bcrypt.hashSync(password,bcrypt.genSaltSync(9));
		
		console.log(hashpass1);
		
		console.log(bcrypt.compareSync(password, hashpass));
		console.log(bcrypt.compareSync(password, hashpass1));
		var query = "select * from user where email='"+username+"'";
		console.log(query);
		mysql.fetchData(function(err,results){
		if(err){
			console.log("Invalid Login");
		throw err;
		
		}
		else
		{
		if(results.length > 0){
			var dbpass=results[0].password;
			if(bcrypt.compareSync(password, dbpass))
				{
		console.log("valid Login"+results[0].firstname);
		req.session.userid=results[0].userid;
		req.session.email=results[0].email;
		req.session.fname=results[0].firstname;
		req.session.lastname=results[0].lastname;
		req.session.mobile=results[0].mobile;
		req.session.ebayhandle=results[0].ebayhandle;
		
		createlog.setlog(req.session.email+" Logged into system");
		
		console.log("The session Created "+req.session.fname);
		json_responses = {"statusCode" : 200};
		console.log("before redirect");
		res.send(json_responses);
				}
		}
		else {
		console.log("Invalid Login");
		json_responses = {"statusCode" : 401};
		res.send(json_responses);
		
		}
		}
		},query);
		
	
	};
	exports.signup=function(req,res)
	{
		console.log("here");
		var json_responses;
		var email = req.param("email");
		var password = req.param("pass");
		var fname=req.param("fname");
		var lname=req.param("lname");
		var phn=req.param("phn");	
		var handle=(fname+"_"+lname).substr(0, 8);
		
		
		var option = {
				ignoredNamespaces : true
			};
			var url = baseURL + "/Login?wsdl";
			var args = {
				username : email,
				password : password,
				firstname :fname,
				lastname :lname,
				mobile : phn,
				handle:handle
			};
			soap.createClient(url, option, function(err, client) {
				client.register(args, function(err, result) {
					var datareceived = JSON.parse(result.registerReturn);
					console.log(datareceived);
					if (datareceived.statusCode == 401) {
						res.send({
							"statusCode" : "401"
						});
					} else {
						
							
						var rows = datareceived.data;
						for ( var i in rows) {

							req.session.userid = rows[i].userid;
							user_id = rows[i].userid;
							username =rows[i].firstname;
							req.session.userid = user_id;
							req.session.username = rows[i].firstname;

							req.session.email = rows[i].email;
							req.session.fname = rows[i].firstname;
							req.session.lastname = rows[i].lastname;
							req.session.mobile = rows[i].mobile;

							console.log("Session initialized for user : " + username);
							json_responses = {
								"statusCode" : 200
							};
							createlog.setlog(rows[0].email+" Registered into system");
							res.send(json_responses);
						}

					
				}});
			});
		
		/*var query = "insert into user(firstname,lastname,email,password,mobile,ebayhandle,personal,business) values ('"+fname+"','"+lname+"','"+email+"','"+password+"','"+phn+"','"+handle+"','N','N')";
		console.log(query);
		mysql.fetchData(function(err,results){
			if(err){
			throw err;
			}
			else
			{
				console.log(results.affectedRows);
			if(results.affectedRows > 0){
			//console.log("Inserted"+results[0].firstname);
			req.session.username=results[0].firstname;
			json_responses = {"statusCode" : 200};
			console.log("before redirect");
			res.send(json_responses);
			createlog.setlog(results[0].email+" Registered into system");

			}
			else {
			console.log("Invalid Login");
			json_responses = {"statusCode" : 401};
			res.send(json_responses);
			
			}
			}
			},query);*/
};
exports.redirectToHomepage = function(req,res)
{
	//Checks before redirecting whether the session is valid
	/*if(req.session.username)
	{
		//Set these headers to notify the browser not to maintain any cache for the page being loaded
		res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
		res.render("homepage",{username:req.session.username});
	}
	else
	{*/
		res.redirect('/');
	//}
};

function afterSignIn(req,res)
{
// check user already exist
var getUser="select * from test.users where username='"+req.param("inputUsername")+"' and password='" +req.param("inputPassword") +"'";
console.log("Query is11:"+getUser);
mysql1.fetchData(function(err,results){
if(err){
throw err;
}
else
{
if(results.length > 0){
console.log("valid Login");
ejs.renderFile('./views/index.ejs', {
data: results } , function(err, result) {
// render on success
if (!err) {
res.end(result);
}
// render or error
else {
res.end('An error occurred');
console.log(err);
}
});
}
else {
console.log("Invalid Login");
ejs.renderFile('./views/failLogin.ejs',function(err, result) {
// render on success
if (!err) {
res.end(result);
}
// render or error
else {
res.end('An error occurred');
console.log(err);
}
});
}
}
},getUser);
}

//Redirects to the homepage
exports.redirectToHomepage = function(req,res)
{

};

//Logout the user - invalidate the session
exports.logout = function(req,res)
{
	req.session.destroy();
	res.redirect('/');
};

