var should=require('should');
var mocha=require('mocha');
var expect=require('chai').expect;
var request =require('request');

describe('returns valid login',function(){
    it('return valid login',function (done) {
        request.get({url:'http:localhost:3000/login'},function (error,response,body) {
            expect(response.statusCode).to.equal(200);
            console.log(body);
            done();
            
        });

    });

});
